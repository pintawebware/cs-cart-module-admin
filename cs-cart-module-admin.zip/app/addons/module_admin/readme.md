# Installation Instructions:

1. Download add-on from github by [link](https://github.com/pintawebware/cs-cart-module-admin/releases/download/2.0/cs-cart-module-admin.zip)

2. Go to "Manage add-ons" (Add-ons -> Manage Add-ons)
![2 step](http://joxi.net/KAgXLvLTgN7qjr.jpg)

3. Press button "+" (Upload & install add-on) 
![3 step](http://joxi.net/vAWpo6oikBl49r.jpg)

4. In the pop-up, click "local" and select the previously downloaded archive with the module. Then click the "Upload & install" button.
![4 step](http://joxi.net/xAeOWzWFYb5Okm.jpg)

5. After installation, you will see the message "installed successfully". 
![5 step](http://joxi.net/MAj9aYauv1o9P2.jpg)

6. CCongratulations, the installation of the module is complete.
You can download the application from iTunes or the Play Market under the links:
[iOS](https://itunes.apple.com/us/app/id1257762085)
[Android](https://play.google.com/store/apps/details?id=com.pinta.cscart.cscartmobileadmin&hl=en)